# Бот в текущей сборке расчитан на работу с heroku.com
# Это ссылка на приложение, для установления вебхука
url = "https://khabarovskiybot.herokuapp.com/bot"

# Имя бота (то, которое @)
bot_name = "khabarovskiybot"
